<template>
  <div class="fileUpload">
    <ManagerRemark />
  </div>
</template>

<script>
// @ is an alias to /src
import ManagerRemark from "@/components/Manager's/ManagerRemark.vue";

export default {
  name: "MRemark",
  components: {
    ManagerRemark
  }
};
</script>
