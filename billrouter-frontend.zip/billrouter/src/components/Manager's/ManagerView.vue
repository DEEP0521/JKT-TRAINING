<template>
  <div class="viewBills">
    <h1>Employee Records!</h1>
    <table>
      <tr>
        <th>Employee ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Bill's Availability</th>
      </tr>
      <tr v-for="employee in employees" v-bind:key="employee.id">
        <td>{{ employee.id }}</td>
        <td>{{ employee.first_name }} {{ employee.last_name }}</td>
        <td>{{ employee.email }}</td>
        <td>
          <button @click="records(employee.id)">
            Employee bills
          </button>
        </td>
      </tr>
    </table>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "ManagerView",
  data: function() {
    return {
      id: this.$route.params.id,
      employees: {},
      employee: {
        id: "",
        first_name: "",
        last_name: "",
        email: ""
      },
      store: {}
    };
  },
  created() {
    this.employeeRecord();
  },
  methods: {
    records(id) {
      axios
        .get("http://localhost:10090//Bills/" + id, {
          headers: { "Access-Control-Allow-Origin": "*" }
        })
        .then(response => {
          this.store = response.data;
          console.log(this.store.length);
          if (this.store.length != 0) {
            let routeData = this.$router.resolve({
              path: "/manageremark/" + id
            });
            window.open(routeData.href, "_blank");
          } else if (this.store.length == 0) {
            alert("No Data Found!");
          }
        })
        .catch(function(errors) {
          console.log(errors);
          alert("NO Record Found!");
        });
    },
    employeeRecord() {
      axios
        .get("http://localhost:10090//admin/" + this.id, {
          headers: { "Access-Control-Allow-Origin": "*" }
        })
        .then(response => {
          this.employees = response.data;
        })
        .catch(function(errors) {
          console.log("Not Found!" + errors);
        });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
table,
tr {
  width: 100%;
  color: ghostwhite;
  font-size: 20px;
  height: auto;
  border: 10px solid rgb(239, 250, 144);
}
th {
  background-color: lightskyblue;
}
td {
  text-align: left;
  background-color: rgb(112, 180, 223);
}
h1 {
  padding-top: 1%;
  text-align: center;
  color: ghostwhite;
  background-color: cornflowerblue;
}
</style>
