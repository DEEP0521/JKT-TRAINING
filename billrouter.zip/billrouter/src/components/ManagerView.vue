<template>
  <div class="viewBills">
    <h3>
      <router-link to="/">EXIT</router-link>
    </h3>
    <h1>Employee Records!</h1>
    <table>
      <tr>
        <th>Employee ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Bill's Availability</th>
      </tr>
      <tr v-for="employee in employees" v-bind:key="employee.id">
        <td>{{ employee.id }}</td>
        <td>{{ employee.first_name }} {{ employee.last_name }}</td>
        <td>{{ employee.email }}</td>
        <td @change="billAvailable(employee.id)">
          <router-link :to="'/manageremark/' + employee.id" target="_blank"
            >Upload Bill</router-link
          >
        </td>
      </tr>
    </table>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "ManagerView",
  data: function() {
    return {
      departid: this.$route.params.id,
      employees: null,
      employee: {
        id: "",
        first_name: "",
        last_name: "",
        email: ""
      },
      store: false
    };
  },
  created() {
    this.emploeeRecord();
  },
  methods: {
    emploeeRecord() {
      axios
        .get("http://localhost:10090//department/" + this.departid, {
          headers: { "Access-Control-Allow-Origin": "*" }
        })
        .then(Response => {
          this.employees = Response.data;
          if (this.employees != 0) {
            console.log("Data Found");
          } else {
            console.log("Data Not Found");
          }
        })
        .catch(function(errors) {
          console.log(errors);
          alert("NO Record Found!");
        });
    },
    billAvailable(empid) {
      axios
        .get("http://localhost:10090//Bills/" + empid, {
          headers: { "Access-Control-Allow-Origin": "*" }
        })
        .then(response => {
          console.log("Responding!");
          if (response.data != null) {
            this.store = true;
            console.log(this.store);
            return this.store;
          } else {
            this.store = false;
            console.log(this.store);
            return this.store;
          }
        })
        .catch(function(errors) {
          console.log(errors);
        });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
table,
tr {
  width: 100%;
  color: ghostwhite;
  font-size: 20px;
  height: auto;
  border: 10px solid rgb(239, 250, 144);
}
th {
  background-color: lightskyblue;
}
td {
  text-align: left;
  background-color: rgb(112, 180, 223);
}
h1 {
  padding-top: 1%;
  text-align: center;
  color: ghostwhite;
  background-color: cornflowerblue;
}
h3 {
  color: ghostwhite;
  text-align: left;
  background-color: cornflowerblue;
  padding-top: 1%;
  height: 40px;
}
</style>
