<template>
  <div class="fileUpload">
    <ManagerRemark />
  </div>
</template>

<script>
// @ is an alias to /src
import ManagerRemark from "@/components/ManagerRemark.vue";

export default {
  name: "MRemark",
  components: {
    ManagerRemark
  }
};
</script>
