<template>
  <div class="fileUpload">
    <ManagerView />
  </div>
</template>

<script>
// @ is an alias to /src
import ManagerView from "@/components/ManagerView.vue";

export default {
  name: "ManagerRecords",
  components: {
    ManagerView
  }
};
</script>
