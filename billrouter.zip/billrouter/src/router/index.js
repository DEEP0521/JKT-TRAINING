/* eslint-disable prettier/prettier */
import Vue from "vue";
import VueRouter from "vue-router";

import LogIn from "../views/LogIn.vue";
import FileSubmit from "../views/FileSubmit.vue";
import BillView from "../views/BillView.vue";
import DepartBill from "../views/DepartBill.vue";
import ManagerRecords from "../views/ManagerRecords";
import MRemark from "../views/MRemark";

Vue.use(VueRouter);

const routes = [{
        path: "/",
        name: "VerifyLogin",
        component: LogIn
    },
    {
        path: "/file/:id",
        name: "FileSubmit",
        component: FileSubmit
    },
    {
        path: "/billview/:id",
        name: "BillView",
        component: BillView
    },
    {
        path: "/departlog",
        name: "DepartBill",
        component: DepartBill
    },
    {
        path: "/managerview/:id",
        name: "Records",
        component: ManagerRecords
    },
    {
        path: "/manageremark/:id",
        name: "MRemark",
        component: MRemark
    }
];

const router = new VueRouter({
    mode: "history",
    base: process.env.BASE_URL,
    routes
});

export default router;