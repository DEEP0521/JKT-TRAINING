<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style>
body {
  background-color: rgb(28, 151, 192);
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;

  box-sizing: border-box;
  /* background-color: rgba(49, 155, 155, 0.719); */
  height: 630px;
  /* border: 30px solid rgb(14, 125, 161); */
}
</style>
