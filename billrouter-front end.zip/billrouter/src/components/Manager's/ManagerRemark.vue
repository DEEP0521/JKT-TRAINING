<template>
  <div class="viewBills">
    <h1>Employee Bills!</h1>
    <table>
      <tr>
        <th>Month</th>
        <th>Reimbursement Type</th>
        <th>View Bill</th>
        <th>Given Remark's</th>
        <th colspan="2">Remark</th>
      </tr>
      <tr v-for="n in store" :key="n.id">
        <td>{{ n.month }}</td>
        <td>{{ n.type }}</td>
        <td>
          <button
            v-show="n.file != null"
            @click="downloadBill(n.id, n.month, n.type)"
          >
            VIEW
          </button>
        </td>
        <td>{{ n.remark }}</td>
        <td>
          <button
            v-if="n.remark != 'ACCEPT' || n.remark == null"
            @click="sendRemark('ACCEPT', n.id)"
          >
            ACCEPT
          </button>
        </td>
        <td>
          <button
            v-if="n.remark == 'ACCEPT' || n.remark == null"
            @click="sendRemark('REJECT', n.id)"
          >
            REJECT
          </button>
        </td>
      </tr>
    </table>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "ManagerRemark",
  data: function() {
    return {
      empid: this.$route.params.id,
      store: [],
      temp: ""
    };
  },
  created() {
    this.loadData();
  },
  methods: {
    sendRemark(value, billid) {
      axios.put("http://localhost:10090/Bills/" + billid, {
        remark: value
      });
      window.location.reload();
    },
    loadData() {
      axios
        .get("http://localhost:10090//Bills/" + this.empid, {
          headers: { "Access-Control-Allow-Origin": "*" }
        })
        .then(response => {
          this.store = response.data;
        })
        .catch(function(errors) {
          console.log(errors);
          alert("NO Record Found!");
        });
    },
    downloadBill(fileId, month, type) {
      axios
        .get("http://localhost:10090//downloadFile/" + fileId, {
          responseType: "blob",
          headers: { "Access-Control-Allow-Origin": "*" }
        })
        .then(response => {
          const file = new Blob([response.data], {
            type: "application/pdf"
          });
          const fileURL = URL.createObjectURL(file);
          const link = document.createElement("a");
          link.href = fileURL;
          link.setAttribute(
            "download",
            this.empid + " " + month + " " + type + ".pdf"
          );
          window.open(link, "_blank");
          // link.click();
        })
        .catch(function(errors) {
          console.log(errors);
          alert("NO Record Found!");
        });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
table,
tr {
  width: 100%;
  color: ghostwhite;
  font-size: 20px;
  height: auto;
  border: 10px solid rgb(239, 250, 144);
}
th {
  background-color: lightskyblue;
}
td {
  background-color: rgb(112, 180, 223);
}
h1 {
  padding-top: 2%;
  text-align: center;
  color: ghostwhite;
  background-color: cornflowerblue;
}
button:focus {
  background-color: greenyellow;
}
button {
  border: none;
  padding: 10px 25px;
  background-color: rgb(33, 74, 161);
  color: ghostwhite;
  font-size: 15px;
  margin: 2px 0px;
}
</style>
