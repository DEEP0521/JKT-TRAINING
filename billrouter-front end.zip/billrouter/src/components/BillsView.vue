<template>
  <div class="viewBills">
    <h3>
      <button @click="$router.push('/file/' + empid)">Upload Bill</button>
      <button @click="$router.push('/')">EXIT</button>
    </h3>
    <h1>Uploaded Bills!</h1>
    <table>
      <tr>
        <th>Month</th>
        <th>Reimbursement Type</th>
        <th>Delete Bill</th>
        <th>View Bill</th>
        <th>Manager Remark</th>
      </tr>
      <tr v-for="n in store" :key="n.id">
        <td>{{ n.month }}</td>
        <td>{{ n.type }}</td>
        <td>
          <button
            id="pick"
            v-show="n.remark != 'ACCEPT'"
            @click="deleteBill(n.id)"
          >
            Delete
          </button>
        </td>
        <td>
          <button id="pick" v-show="n.file != null" @click="downloadBill(n.id)">
            VIEW
          </button>
        </td>
        <td>{{ n.remark }}</td>
      </tr>
    </table>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "BillsView",
  data: function() {
    return {
      empid: this.$route.params.id,
      store: [],
      temp: ""
    };
  },
  created() {
    axios
      .get("http://localhost:10090//Bills/" + this.empid, {
        headers: { "Access-Control-Allow-Origin": "*" }
      })
      .then(response => {
        this.store = response.data;
        // console.log(this.store.length);
        this.month = this.store.month;
        this.type = this.store.type;
        if (this.store.length != 0) {
          // console.log("Data Found!");
        } else if (this.store.length == 0) {
          alert("Bills Not Found!");
          this.$router.push({
            path: "/file/" + this.empid
          });
        }
      })
      .catch(function(errors) {
        console.log(errors);
        alert("NO Record Found!");
        this.$router.push({
          path: "/file/" + this.empid
        });
      });
  },
  methods: {
    downloadBill(fileId) {
      axios
        .get("http://localhost:10090//downloadFile/" + fileId, {
          responseType: "blob",
          headers: { "Access-Control-Allow-Origin": "*" }
        })
        .then(response => {
          const file = new Blob([response.data], {
            type: "application/pdf"
          });
          const fileURL = URL.createObjectURL(file);
          window.open(fileURL, "_blank");
        })
        .catch(function(errors) {
          console.log(errors);
          alert("NO Record Found!");
        });
    },
    deleteBill(fileId) {
      axios
        .delete("http://localhost:10090//Bills/" + fileId, {
          headers: { "Access-Control-Allow-Origin": "*" }
        })
        .then(response => {
          this.temp = response.data;
          if (this.temp != null) {
            window.location.reload();
          } else {
            console.log("Internal Error");
          }
        })
        .catch(function(errors) {
          console.log(errors);
          alert("NO Record Found!");
        });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
table,
tr {
  width: 100%;
  color: ghostwhite;
  font-size: 20px;
  height: auto;
  border: 10px solid rgb(239, 250, 144);
}
th {
  background-color: lightskyblue;
}
td {
  background-color: rgb(112, 180, 223);
}
h1 {
  padding-top: 2%;
  text-align: center;
  color: ghostwhite;
  background-color: cornflowerblue;
}
h3 {
  color: ghostwhite;
  text-align: left;
  background-color: cornflowerblue;
  height: 60px;
}
button {
  border: none;
  padding: 15px 32px;
  background-color: rgb(33, 74, 161);
  color: ghostwhite;
  font-size: 16px;
  margin: 4px 2px;
}
#pick {
  border: none;
  padding: 10px 25px;
  background-color: rgb(33, 74, 161);
  color: ghostwhite;
  font-size: 15px;
  margin: 2px 0px;
}
</style>
